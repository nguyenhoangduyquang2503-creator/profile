function createSnow() {
    for (let i = 0; i < 20; i++) {
        let s = document.createElement("div");
        s.className = "snowflake";
        s.innerHTML = "*";
        s.style.left = Math.random() * 110 + "vw";
        s.style.fontSize = (12 + Math.random() * 18) + "px";
        s.style.animationDuration = (5 + Math.random() * 40) + "s";
        document.body.appendChild(s);
    }
}
window.onload = function () {
    alert("dangky");
    alert("CÂU LẠC BỘ TIN HỌC");
    alert("Chúc mừng Giáng Sinh - Merry Christmas 🎄");
    createSnow();
};